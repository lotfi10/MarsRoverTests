package com.bnp.testnexeo;

import com.bnp.testnexeo.commandsListe.Commands;
import com.bnp.testnexeo.directionsListe.Directions;
import com.bnp.testnexeo.models.Plateau;
import com.bnp.testnexeo.models.Rover;
/**
 * 
 * @author Lotfi Fetteni
 *
 */
public abstract class MainTest {
	
	
	protected final Plateau plateau = new Plateau(5, 5);
    protected int xCoordinate = 2;
    protected int yCoordinate = 2;
    protected Directions direction;
    protected Rover rover;
    protected Commands command;

}
