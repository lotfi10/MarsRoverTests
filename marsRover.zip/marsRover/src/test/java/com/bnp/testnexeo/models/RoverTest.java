package com.bnp.testnexeo.models;

import com.bnp.testnexeo.MainTest;
import com.bnp.testnexeo.commandsListe.Commands;
import com.bnp.testnexeo.commandsListe.MoveForwardCommands;
import com.bnp.testnexeo.commandsListe.SpinLeftCommands;
import com.bnp.testnexeo.commandsListe.SpinRightCommands;
import com.bnp.testnexeo.directionsListe.EastDirection;
import com.bnp.testnexeo.directionsListe.NorthDirection;
import com.bnp.testnexeo.directionsListe.WestDirection;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static junit.framework.TestCase.assertEquals;

/**
 * 
 * @author Lotfi Fetteni
 *
 */

public class RoverTest extends MainTest {

    @Before
    public void setUp() throws Exception {
        direction = new NorthDirection();
        rover = new Rover(plateau, xCoordinate, yCoordinate, direction);
    }

    @Test
    public void whenRequestedRoverCanSpinRight() throws Exception {
        rover.spinRight();
        assertEquals(EastDirection.class, rover.getDirection().getClass());
    }

    @Test
    public void whenRequestedRoverCanSpinLeft() throws Exception {
        rover.spinLeft();
        assertEquals(WestDirection.class, rover.getDirection().getClass());
    }

    @Test
    public void whenRequestedRoverCanMoveForward() throws Exception {
        rover.moveForward();
        assertEquals(++yCoordinate, rover.getCoordinateY());
    }

    @Test
    public void whenRequestedRoverCanMoveBack() throws Exception {
        rover.moveBack();
        assertEquals(--yCoordinate, rover.getCoordinateY());
    }

    @Test
    public void whenRequestedRoverCanPrintCurrentPosition() throws Exception {
        assertEquals(xCoordinate + " "
                + yCoordinate + " "
                + direction.getClass().getSimpleName().charAt(0), rover.broadcastLocation());
    }

    @Test
    public void whenRequestedRoverCanExecuteCommandAsAList() throws Exception {
        ArrayList<Commands> commandArrayList = new ArrayList<>();
        commandArrayList.add(new MoveForwardCommands());
        commandArrayList.add(new MoveForwardCommands());
        commandArrayList.add(new SpinLeftCommands());
        commandArrayList.add(new MoveForwardCommands());
        commandArrayList.add(new SpinRightCommands());
        rover.executeCommandList(commandArrayList);

        assertEquals(1, rover.getCoordinateX());
        assertEquals(4, rover.getCoordinateY());
        assertEquals(NorthDirection.class, rover.getDirection().getClass());
    }

    @Test
    public void whenHardCodedTestInputIsRunCorrectOutputIsReturned() {
        // Test Input:
        // 5 5
        Plateau plateau = new Plateau(5, 5);

        // 1 2 N
        Rover roverOne = new Rover(plateau, 1, 2, new NorthDirection());

        // LMLMLMLMM
        ArrayList<Commands> roverOneCommands = new ArrayList<>();
        roverOneCommands.add(new SpinLeftCommands());
        roverOneCommands.add(new MoveForwardCommands());
        roverOneCommands.add(new SpinLeftCommands());
        roverOneCommands.add(new MoveForwardCommands());
        roverOneCommands.add(new SpinLeftCommands());
        roverOneCommands.add(new MoveForwardCommands());
        roverOneCommands.add(new SpinLeftCommands());
        roverOneCommands.add(new MoveForwardCommands());
        roverOneCommands.add(new MoveForwardCommands());
        roverOne.executeCommandList(roverOneCommands);

        // 3 3 E
        Rover roverTwo = new Rover(plateau, 3, 3, new EastDirection());

        // MMRMMRMRRM
        ArrayList<Commands> roverTwoCommands = new ArrayList<>();
        roverTwoCommands.add(new MoveForwardCommands());
        roverTwoCommands.add(new MoveForwardCommands());
        roverTwoCommands.add(new SpinRightCommands());
        roverTwoCommands.add(new MoveForwardCommands());
        roverTwoCommands.add(new MoveForwardCommands());
        roverTwoCommands.add(new SpinRightCommands());
        roverTwoCommands.add(new MoveForwardCommands());
        roverTwoCommands.add(new SpinRightCommands());
        roverTwoCommands.add(new SpinRightCommands());
        roverTwoCommands.add(new MoveForwardCommands());
        roverTwo.executeCommandList(roverTwoCommands);

        // Expected Output:
        // 1 3 N
        assertEquals(1, roverOne.getCoordinateX());
        assertEquals(3, roverOne.getCoordinateY());
        assertEquals(NorthDirection.class, roverOne.getDirection().getClass());

        // 5 1 E
        assertEquals(5, roverTwo.getCoordinateX());
        assertEquals(1, roverTwo.getCoordinateY());
        assertEquals(EastDirection.class, roverTwo.getDirection().getClass());
    }
}
