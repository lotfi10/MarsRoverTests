package com.bnp.testnexeo.commandsListeTests;

import com.bnp.testnexeo.MainTest;
import com.bnp.testnexeo.commandsListe.SpinLeftCommands;
import com.bnp.testnexeo.directionsListe.NorthDirection;
import com.bnp.testnexeo.directionsListe.WestDirection;
import com.bnp.testnexeo.models.Rover;

import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

/**
 * 
 * @author Lotfi Fetteni
 *
 */

public class SpinLeftCommandTest extends MainTest {

    @Before
    public void setUp() throws Exception {
        direction = new NorthDirection();
        rover = new Rover(plateau, xCoordinate, yCoordinate, direction);
        command = new SpinLeftCommands();
    }

    @Test
    public void whenSpinLeftCommandIsExecutedRoverSpinsLeft() throws Exception {
        command.executeMovement(rover);
        assertEquals(WestDirection.class, rover.getDirection().getClass());
    }
}
