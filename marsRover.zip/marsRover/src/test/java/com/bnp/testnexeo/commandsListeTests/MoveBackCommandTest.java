package com.bnp.testnexeo.commandsListeTests;


import org.junit.Before;
import org.junit.Test;

import com.bnp.testnexeo.MainTest;
import com.bnp.testnexeo.commandsListe.MoveBackCommands;
import com.bnp.testnexeo.directionsListe.NorthDirection;
import com.bnp.testnexeo.models.Rover;

import static junit.framework.TestCase.assertEquals;
/**
 * 
 * @author Lotfi Fetteni
 *
 */

public class MoveBackCommandTest extends MainTest {

    @Before
    public void setUp() throws Exception {
        direction = new NorthDirection();
        rover = new Rover(plateau, xCoordinate, yCoordinate, direction);
        command = new MoveBackCommands();
    }

    @Test
    public void whenMoveBackCommandIsExecutedRoverMovesBack() throws Exception {
        command.executeMovement(rover);
        assertEquals(--yCoordinate, rover.getCoordinateY());
    }
}
