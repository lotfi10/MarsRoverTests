package com.bnp.testnexeo;


import org.junit.Test;

import com.bnp.testnexeo.commandsListe.Commands;
import com.bnp.testnexeo.commandsListe.MoveBackCommands;
import com.bnp.testnexeo.commandsListe.MoveForwardCommands;
import com.bnp.testnexeo.commandsListe.SpinLeftCommands;
import com.bnp.testnexeo.commandsListe.SpinRightCommands;
import com.bnp.testnexeo.directionsListe.NorthDirection;
import com.bnp.testnexeo.models.Plateau;
import com.bnp.testnexeo.models.Rover;

import java.io.InputStream;
import java.util.ArrayList;

import static junit.framework.TestCase.assertEquals;

public class InputUtilTest extends MainTest {

    @Test
    public void inputStringsCanBeParsedFromFile() throws Exception {
        InputStream testFileInputStream = getClass().getResourceAsStream("/testInput.txt");
        String expectedInputStringOne = "5 5";
        String expectedInputStringTwo = "1 2 N";
        String expectedInputStringThree = "LMLMLMLMM";
        String expectedInputStringFour = "3 3 E";
        String expectedInputStringFive = "MMRMMRMRRM";
        ArrayList<String> testFileLines = InputUtils.parseInputFromFile(testFileInputStream);

        assertEquals(5, testFileLines.size());
        assertEquals(expectedInputStringOne, testFileLines.get(0));
        assertEquals(expectedInputStringTwo, testFileLines.get(1));
        assertEquals(expectedInputStringThree, testFileLines.get(2));
        assertEquals(expectedInputStringFour, testFileLines.get(3));
        assertEquals(expectedInputStringFive, testFileLines.get(4));
    }

    @Test
    public void whenPlateauInputIsParsedPlateauIsConstructed() throws Exception {
        String plateauInput = "5 5";
        Plateau plateauOutput = InputUtils.parsePlateauInput(plateauInput);

        assertEquals(0, plateauOutput.getLowerBoundCoordinateX());
        assertEquals(0, plateauOutput.getLowerBoundCoordinateY());
        assertEquals(5, plateauOutput.getUpperBoundCoordinateX());
        assertEquals(5, plateauOutput.getUpperBoundCoordinateY());
    }

    @Test
    public void whenPositionInputIsParsedRoverIsConstructed() throws Exception {
        String positionInput = "1 2 N";
        Rover roverOutput = InputUtils.parsePositionInput(positionInput, plateau);

        assertEquals(1, roverOutput.getCoordinateX());
        assertEquals(2, roverOutput.getCoordinateY());
        assertEquals(NorthDirection.class, roverOutput.getDirection().getClass());
    }

    @Test
    public void whenRCommandIsParsedSpinRightCommandIsConstructed() throws Exception {
        String rCommandInput = "R";
        ArrayList<Commands> commandOutput = InputUtils.parseCommandInput(rCommandInput);

        assertEquals(rCommandInput.length(), commandOutput.size());
        assertEquals(SpinRightCommands.class, commandOutput.get(0).getClass());
    }

    @Test
    public void whenLCommandIsParsedSpinLeftCommandIsConstructed() throws Exception {
        String lCommandInput = "L";
        ArrayList<Commands> commandOutput = InputUtils.parseCommandInput(lCommandInput);

        assertEquals(lCommandInput.length(), commandOutput.size());
        assertEquals(SpinLeftCommands.class, commandOutput.get(0).getClass());
    }

    @Test
    public void whenMCommandIsParsedMoveForwardCommandIsConstructed() throws Exception {
        String mCommandInput = "M";
        ArrayList<Commands> commandOutput = InputUtils.parseCommandInput(mCommandInput);

        assertEquals(mCommandInput.length(), commandOutput.size());
        assertEquals(MoveForwardCommands.class, commandOutput.get(0).getClass());
    }

    @Test
    public void whenBCommandIsParsedMoveBackCommandIsConstructed() throws Exception {
        String mCommandInput = "B";
        ArrayList<Commands> commandOutput = InputUtils.parseCommandInput(mCommandInput);

        assertEquals(mCommandInput.length(), commandOutput.size());
        assertEquals(MoveBackCommands.class, commandOutput.get(0).getClass());
    }

    @Test
    public void whenMultipleCommandsAreParsedCommandListIsConstructed() throws Exception {
        String multiCommandInput = "RLM";
        ArrayList<Commands> commandOutput = InputUtils.parseCommandInput(multiCommandInput);

        assertEquals(multiCommandInput.length(), commandOutput.size());
        assertEquals(SpinRightCommands.class, commandOutput.get(0).getClass());
        assertEquals(SpinLeftCommands.class, commandOutput.get(1).getClass());
        assertEquals(MoveForwardCommands.class, commandOutput.get(2).getClass());
    }
}
