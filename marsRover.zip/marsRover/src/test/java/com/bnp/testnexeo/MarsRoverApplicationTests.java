package com.bnp.testnexeo;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import com.bnp.testnexeo.commandsListeTests.MoveBackCommandTest;
import com.bnp.testnexeo.commandsListeTests.MoveForwardCommandTest;
import com.bnp.testnexeo.commandsListeTests.SpinLeftCommandTest;
import com.bnp.testnexeo.commandsListeTests.SpinRightCommandTest;
import com.bnp.testnexeo.directionsListe.EastDirectionTest;
import com.bnp.testnexeo.directionsListe.NorthDirectionTest;
import com.bnp.testnexeo.directionsListe.SouthDirectionTest;
import com.bnp.testnexeo.directionsListe.WestDirectionTest;
import com.bnp.testnexeo.exceptions.RoverExceptionTest;
import com.bnp.testnexeo.models.PlateauTest;
import com.bnp.testnexeo.models.RoverTest;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        MoveBackCommandTest.class,
        MoveForwardCommandTest.class,
        SpinLeftCommandTest.class,
        SpinRightCommandTest.class,
        EastDirectionTest.class,
        NorthDirectionTest.class,
        SouthDirectionTest.class,
        WestDirectionTest.class,
        RoverTest.class,
        RoverExceptionTest.class,
        InputUtilTest.class,
        PlateauTest.class
})
class MarsRoverApplicationTests extends MainTest{


}
