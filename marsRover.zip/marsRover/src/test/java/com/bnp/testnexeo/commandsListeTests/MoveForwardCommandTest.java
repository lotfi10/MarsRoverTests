package com.bnp.testnexeo.commandsListeTests;


import org.junit.Before;
import org.junit.Test;

import com.bnp.testnexeo.MainTest;
import com.bnp.testnexeo.commandsListe.MoveForwardCommands;
import com.bnp.testnexeo.directionsListe.NorthDirection;
import com.bnp.testnexeo.models.Rover;

import static junit.framework.TestCase.assertEquals;

/**
 * 
 * @author Lotfi Fetteni
 *
 */

public class MoveForwardCommandTest extends MainTest {

    @Before
    public void setUp() throws Exception {
        direction = new NorthDirection();
        rover = new Rover(plateau, xCoordinate, yCoordinate, direction);
        command = new MoveForwardCommands();
    }

    @Test
    public void whenMoveForwardCommandIsExecutedRoverMovesForward() throws Exception {
        command.executeMovement(rover);
        assertEquals(++yCoordinate, rover.getCoordinateY());
    }
}
