package com.bnp.testnexeo.models;

import org.junit.Test;

import com.bnp.testnexeo.MainTest;

import static junit.framework.TestCase.assertEquals;

/**
 * 
 * @author Lotfi Fetteni
 *
 */

public class PlateauTest extends MainTest {

    @Test
    public void whenPlateauIsConstructedLowerLeftCoordinatesAreZeroZero() throws Exception {
        assertEquals(0, plateau.getLowerBoundCoordinateX());
        assertEquals(0, plateau.getLowerBoundCoordinateY());
    }
}
