package com.bnp.testnexeo.commandsListeTests;


import org.junit.Before;
import org.junit.Test;

import com.bnp.testnexeo.MainTest;
import com.bnp.testnexeo.commandsListe.SpinRightCommands;
import com.bnp.testnexeo.directionsListe.EastDirection;
import com.bnp.testnexeo.directionsListe.NorthDirection;
import com.bnp.testnexeo.models.Rover;

import static junit.framework.TestCase.assertEquals;

/**
 * 
 * @author Lotfi Fetteni
 *
 */

public class SpinRightCommandTest extends MainTest {

    @Before
    public void setUp() throws Exception {
        direction = new NorthDirection();
        rover = new Rover(plateau, xCoordinate, yCoordinate, direction);
        command = new SpinRightCommands();
    }

    @Test
    public void whenSpinRightCommandIsExecutedRoverSpinsRight() throws Exception {
        command.executeMovement(rover);
        assertEquals(EastDirection.class, rover.getDirection().getClass());
    }
}
