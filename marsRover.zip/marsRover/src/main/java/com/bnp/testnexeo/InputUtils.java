package com.bnp.testnexeo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import com.bnp.testnexeo.commandsListe.Commands;
import com.bnp.testnexeo.commandsListe.LookUpCommands;
import com.bnp.testnexeo.directionsListe.Directions;
import com.bnp.testnexeo.directionsListe.LookUpDirections;
import com.bnp.testnexeo.models.Plateau;
import com.bnp.testnexeo.models.Rover;


/**
 * 
 * @author Lotfi Fetteni
 *
 */
public class InputUtils {


    public static ArrayList<String> parseInputFromFile(InputStream fileLocation) throws IOException {
        ArrayList<String> inputsFromFile = new ArrayList<>();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileLocation));
        String fileLine;

        while ((fileLine = bufferedReader.readLine()) != null)
            inputsFromFile.add(fileLine);

        bufferedReader.close();
        return inputsFromFile;
    }

    public static Plateau parsePlateauInput(String plateauInput) {
        String[] inputArray = plateauInput.split(" ");
        int plateauUpperBoundCoordinateX = Integer.parseInt(inputArray[0]);
        int plateauUpperBoundCoordinateY = Integer.parseInt(inputArray[1]);
        return new Plateau(plateauUpperBoundCoordinateX, plateauUpperBoundCoordinateY);
    }

    public static Rover parsePositionInput(String positionInput, Plateau plateau) {
        String[] inputArray = positionInput.split(" ");
        int roverLandingCoordinateX = Integer.parseInt(inputArray[0]);
        int roverLandingCoordinateY = Integer.parseInt(inputArray[1]);
        Directions direction = LookUpDirections.valueOf(inputArray[2]).getDirection();
        return new Rover(plateau, roverLandingCoordinateX, roverLandingCoordinateY, direction);
    }

    public static ArrayList<Commands> parseCommandInput(String command) {
        char[] inputArray = command.toCharArray();
        ArrayList<Commands> commandArrayList = new ArrayList<>();

        for (char character : inputArray) {
            Commands currentCommand = LookUpCommands.valueOf(Character.toString(character)).getCommand();
            commandArrayList.add(currentCommand);
        }

        return commandArrayList;
    }

}
