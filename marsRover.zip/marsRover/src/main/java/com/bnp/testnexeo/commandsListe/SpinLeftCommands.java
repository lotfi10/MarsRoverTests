package com.bnp.testnexeo.commandsListe;

import com.bnp.testnexeo.models.Rover;
/**
 * 
 * @author Lotfi Feteni
 *
 */
public class SpinLeftCommands implements Commands{
	
	
	@Override
	public void executeMovement(Rover rover) {
		// TODO Auto-generated method stub
		rover.spinLeft();
	}

}
