package com.bnp.testnexeo.exceptions;

/**
 * 
 * @author Lotfi  Fetteni
 *
 */
public class RoverOutOfBoundsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2128830189328811177L;

}
