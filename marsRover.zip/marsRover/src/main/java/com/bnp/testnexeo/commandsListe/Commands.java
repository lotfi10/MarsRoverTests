package com.bnp.testnexeo.commandsListe;

import com.bnp.testnexeo.models.Rover;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
public interface Commands {

	 public abstract void executeMovement(Rover rover);
	
}
