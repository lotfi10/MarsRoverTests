package com.bnp.testnexeo.commandsListe;


/**
 * 
 * @author Lotfi Fetteni
 *
 */

public enum LookUpCommands {
            
    R(new SpinRightCommands()),

    L(new SpinLeftCommands()),

    M(new MoveForwardCommands()),

    B(new MoveBackCommands());

    private final Commands command;

    private LookUpCommands(Commands command) {
        this.command = command;
    }

    public Commands getCommand() {
        return command;
    }

}
