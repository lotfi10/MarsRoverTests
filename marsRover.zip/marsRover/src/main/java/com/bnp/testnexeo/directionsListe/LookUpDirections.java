package com.bnp.testnexeo.directionsListe;



/**
 * 
 * @author Lotfi Fetteni
 *
 */
public enum LookUpDirections {
      
	
    N(new NorthDirection()),

    E(new EastDirection()),

    S(new SouthDirection()),

    W(new WestDirection());

    private final Directions direction;

    
    LookUpDirections(Directions direction) {
        this.direction = direction;
    }

    public Directions getDirection() {
        return direction;
    }

}
