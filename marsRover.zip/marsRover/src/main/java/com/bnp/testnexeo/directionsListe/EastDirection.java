package com.bnp.testnexeo.directionsListe;

import com.bnp.testnexeo.models.Rover;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
public class EastDirection implements Directions{



    @Override
    public Directions spinRight() {
        return new SouthDirection();
    }

    @Override
    public Directions spinLeft() {
        return new NorthDirection();
    }

    @Override
    public void moveForward(Rover rover) {
        rover.setCoordinateX(rover.getCoordinateX() + 1);
    }

    @Override
    public void moveBack(Rover rover) {
        rover.setCoordinateX(rover.getCoordinateX() - 1);
    }

	
	
	   

}
