package com.bnp.testnexeo.directionsListe;

import com.bnp.testnexeo.models.Rover;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
public class NorthDirection implements Directions{


    @Override
    public Directions spinRight() {
        return new EastDirection();
    }

    @Override
    public Directions spinLeft() {
        return new WestDirection();
    }

    @Override
    public void moveForward(Rover rover) {
        rover.setCoordinateY(rover.getCoordinateY() + 1);
    }

    @Override
    public void moveBack(Rover rover) {
        rover.setCoordinateY(rover.getCoordinateY() - 1);
    }


}
