package com.bnp.testnexeo.directionsListe;

import com.bnp.testnexeo.models.Rover;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
public interface Directions {
     
	
    public abstract Directions spinRight();

    public abstract Directions spinLeft();

    public abstract void moveForward(Rover rover);

    public abstract void moveBack(Rover rover);

	      
}
