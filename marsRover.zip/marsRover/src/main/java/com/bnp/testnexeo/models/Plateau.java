package com.bnp.testnexeo.models;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
public class Plateau {
                  
	    private final int lowerCoordinateX = 0;
	    private final int lowerCoordinateY = 0;
	    private final int upperCoordinateX;
	    private final int upperCoordinateY;

	    
	    public Plateau(int upperBoundCoordinateX, int upperBoundCoordinateY) {
	        this.upperCoordinateX = upperBoundCoordinateX;
	        this.upperCoordinateY = upperBoundCoordinateY;
	    }

	    public int getUpperBoundCoordinateX() {
	        return upperCoordinateX;
	    }

	    public int getUpperBoundCoordinateY() {
	        return upperCoordinateY;
	    }

	    public int getLowerBoundCoordinateX() {
	        return lowerCoordinateX;
	    }

	    public int getLowerBoundCoordinateY() {
	        return lowerCoordinateY;
	    }
}
