package com.bnp.testnexeo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bnp.testnexeo.commandsListe.Commands;
import com.bnp.testnexeo.models.Plateau;
import com.bnp.testnexeo.models.Rover;

/**
 * 
 * @author Lotfi Fetteni
 *
 */

//@SpringBootApplication
public class MarsRoverApplication {

//	public static void main(String[] args) {
//		//SpringApplication.run(MarsRoverApplication.class, args);
//		
//		
//	}
	
    public static void main(String[] args) throws IOException {

        ArrayList<String> inputFileAsList = InputUtils.parseInputFromFile(MarsRoverApplication.class.getResourceAsStream("/input.txt"));
        
        // The first instruction is separated out, as this is for creating the Plateau, which is global for all Rovers
        List<String> roverInput = inputFileAsList.subList(1, inputFileAsList.size());

        System.out.println("Input:" + "\n");
        
        // read the input file as a List from input.txt file
       
        for (String line : inputFileAsList)
        	
            System.out.println(line);

        System.out.println("\n" + "Output:" + "\n");
        
        Plateau plateau = InputUtils.parsePlateauInput(inputFileAsList.get(0));
        
        // Subsequent pairs of instructions are used to create a Rover and a set of Commands
        // We  run the set of Commands on that Rover and repeat this for the next pair of instructions
        
        for (int i = 0; i < roverInput.size(); i += 2) {
        	
            Rover rover = InputUtils.parsePositionInput(roverInput.get(i), plateau);
            ArrayList<Commands> commands = InputUtils.parseCommandInput(roverInput.get(i + 1));
            rover.executeCommandList(commands);
            System.out.println(rover.broadcastLocation());
            
        }
        
    }

}
