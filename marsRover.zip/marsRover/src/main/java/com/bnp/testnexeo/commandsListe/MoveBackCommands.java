package com.bnp.testnexeo.commandsListe;

import com.bnp.testnexeo.models.Rover;

/**
 * 
 * @author Lotfi Fetteni
 *
 */
public class MoveBackCommands implements Commands{

	@Override
	public void executeMovement(Rover rover) {
				
		rover.moveBack();
		
	}

}
